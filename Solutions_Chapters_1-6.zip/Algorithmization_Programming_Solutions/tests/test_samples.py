from pathlib import Path
import contextlib, io, runpy, sys
root=Path(__file__).resolve().parents[1]
paths={
'3.1': ('Chapter_03_Python_Basics/Solutions/Exercise_01_Arithmetic.py','17 5\n','17 + 5 = 22\n17 - 5 = 12\n17 * 5 = 85\n17 / 5 = 3.40\n17 // 5 = 3\n17 % 5 = 2'),
'3.2': ('Chapter_03_Python_Basics/Solutions/Exercise_02_Time_Formatting.py','3725\n','1:02:05'),
'3.3': ('Chapter_03_Python_Basics/Solutions/Exercise_03_Digit_Extraction.py','473\n','4 7 3, сума = 14'),
'3.4': ('Chapter_03_Python_Basics/Solutions/Exercise_04_Circle.py','2.5\n','C = 15.71, S = 19.63'),
'3.5': ('Chapter_03_Python_Basics/Solutions/Exercise_05_Distance_Between_Points.py','0 0 3 4\n','d = 5.00'),
'3.6': ('Chapter_03_Python_Basics/Solutions/Exercise_06_Right_Triangle.py','3 4\n','c = 5.00, P = 12.00, S = 6.00'),
'3.7': ('Chapter_03_Python_Basics/Solutions/Exercise_07_Compound_Interest.py','1000 10\n','1331.00'),
'3.8': ('Chapter_03_Python_Basics/Solutions/Exercise_08_BMI.py','70 1.75\n','IMT = 22.86'),
'3.9': ('Chapter_03_Python_Basics/Solutions/Exercise_09_GCD_and_LCM.py','12 18\n','НСД = 6, НСК = 36'),
'3.10': ('Chapter_03_Python_Basics/Solutions/Exercise_10_VAT.py','120 0.5 20\n','без ПДВ: 60.00\nПДВ:     12.00\nразом:   72.00'),
'4.1': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_01_Reverse_Four_Digits.py','1234\n','4321'),
'4.2': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_02_Five_Digit_Sum_and_Product.py','12345\n','сума = 15, добуток = 120'),
'4.3': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_03_Minutes_to_Days_Hours.py','1500\n','1 діб 1 год 0 хв'),
'4.4': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_04_Swap_First_and_Last_Digits.py','473\n','374'),
'4.5': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_05_Days_to_Weeks.py','25\n','3 тиж 4 дн'),
'4.6': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_06_Kopecks_to_Hryvnia.py','1205\n','12 грн 05 коп'),
'4.7': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_07_Left_Rotation_of_Digits.py','1234\n','2341'),
'4.8': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_08_Centimetres_and_Inches.py','375\n','3 м 75 см, 147 дюймів'),
'4.9': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_09_Reverse_Two_Digit_Number.py','38\n','83, сума = 121'),
'4.10': ('Chapter_04_Linear_Algorithms/Solutions/Exercise_10_Format_Date.py','150326\n','15.03.2026'),
'5.1': ('Chapter_05_Conditionals/Solutions/Exercise_01_Maximum_of_Three.py','5 9 2\n','9'),
'5.2': ('Chapter_05_Conditionals/Solutions/Exercise_02_Number_Sign.py','-7\n','від\'ємне'),
'5.3': ('Chapter_05_Conditionals/Solutions/Exercise_03_Leap_Year.py','1900\n','ні'),
'5.4': ('Chapter_05_Conditionals/Solutions/Exercise_04_Point_Quadrant.py','0 7\n','на осі OY'),
'5.5': ('Chapter_05_Conditionals/Solutions/Exercise_05_Triangle_Type.py','5 5 8\n','рівнобедрений'),
'5.6': ('Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py','60\n','E'),
'5.7': ('Chapter_05_Conditionals/Solutions/Exercise_07_Month_and_Season.py','13\n','помилка'),
'5.8': ('Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py','1 -3 2\n','x1=2, x2=1'),
'5.9': ('Chapter_05_Conditionals/Solutions/Exercise_09_Baggage_Fee.py','25 econom\n','75'),
'5.10': ('Chapter_05_Conditionals/Solutions/Exercise_10_Concessionary_Travel.py','62 ж\n','так'),
'6.1': ('Chapter_06_Loops/Solutions/Exercise_01_Digit_Sum_and_Product.py','12345\n','сума = 15, добуток = 120'),
'6.2': ('Chapter_06_Loops/Solutions/Exercise_02_Digit_Counts.py','70524\n','цифр = 5, парних = 3'),
'6.3': ('Chapter_06_Loops/Solutions/Exercise_03_Minimum_and_Maximum_Digit.py','58391\n','max = 9, min = 1'),
'6.4': ('Chapter_06_Loops/Solutions/Exercise_04_Reverse_Number.py','1200\n','21'),
'6.5': ('Chapter_06_Loops/Solutions/Exercise_05_Divisors.py','12\n','1 2 3 4 6 12 (6 дільників)'),
'6.6': ('Chapter_06_Loops/Solutions/Exercise_06_Prime_Check.py','1\n','ні просте, ні складене'),
'6.7': ('Chapter_06_Loops/Solutions/Exercise_07_Fibonacci.py','7\n','0 1 1 2 3 5 8, сума = 20'),
'6.8': ('Chapter_06_Loops/Solutions/Exercise_08_Factorial_and_Factorial_Sum.py','5\n','5! = 120, сума = 153'),
'6.9': ('Chapter_06_Loops/Solutions/Exercise_09_Primes_Up_to_N.py','20\n','2 3 5 7 11 13 17 19 (8 чисел)'),
'6.10': ('Chapter_06_Loops/Solutions/Exercise_10_Perfect_Number.py','28\n','досконале'),
}
extra_tests = [
    ('5.1 equal values', 'Chapter_05_Conditionals/Solutions/Exercise_01_Maximum_of_Three.py', '7 7 7\n', '7'),
    ('5.3 leap 2000', 'Chapter_05_Conditionals/Solutions/Exercise_03_Leap_Year.py', '2000\n', 'так'),
    ('5.3 non-leap 2023', 'Chapter_05_Conditionals/Solutions/Exercise_03_Leap_Year.py', '2023\n', 'ні'),
    ('5.4 origin', 'Chapter_05_Conditionals/Solutions/Exercise_04_Point_Quadrant.py', '0 0\n', 'початок'),
    ('5.4 first quadrant', 'Chapter_05_Conditionals/Solutions/Exercise_04_Point_Quadrant.py', '3 4\n', 'I'),
    ('5.5 equilateral', 'Chapter_05_Conditionals/Solutions/Exercise_05_Triangle_Type.py', '2 2 2\n', 'рівносторонній'),
    ('5.5 invalid triangle', 'Chapter_05_Conditionals/Solutions/Exercise_05_Triangle_Type.py', '1 2 10\n', 'не трикутник'),
    ('5.5 scalene', 'Chapter_05_Conditionals/Solutions/Exercise_05_Triangle_Type.py', '3 4 5\n', 'різносторонній'),
    ('5.6 lower A boundary', 'Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py', '90\n', 'A'),
    ('5.6 lower B boundary', 'Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py', '82\n', 'B'),
    ('5.6 lower FX boundary', 'Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py', '35\n', 'FX'),
    ('5.6 lower F boundary', 'Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py', '34\n', 'F'),
    ('5.6 out of range', 'Chapter_05_Conditionals/Solutions/Exercise_06_ECTS_Grade.py', '101\n', 'помилка'),
    ('5.7 winter', 'Chapter_05_Conditionals/Solutions/Exercise_07_Month_and_Season.py', '12\n', 'зима'),
    ('5.7 summer', 'Chapter_05_Conditionals/Solutions/Exercise_07_Month_and_Season.py', '7\n', 'літо'),
    ('5.8 double root', 'Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py', '1 2 1\n', 'x=-1'),
    ('5.8 no real roots', 'Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py', '1 0 1\n', 'коренів немає'),
    ('5.8 linear case', 'Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py', '0 2 4\n', 'лінійне: x=-2'),
    ('5.8 infinitely many solutions', 'Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py', '0 0 0\n', "безліч розв'язків"),
    ('5.8 inconsistent equation', 'Chapter_05_Conditionals/Solutions/Exercise_08_Quadratic_Equation.py', '0 0 3\n', 'коренів немає'),
    ('5.9 no excess, economy', 'Chapter_05_Conditionals/Solutions/Exercise_09_Baggage_Fee.py', '18 econom\n', '0'),
    ('5.9 business excess', 'Chapter_05_Conditionals/Solutions/Exercise_09_Baggage_Fee.py', '35 business\n', '75'),
    ('5.10 minor', 'Chapter_05_Conditionals/Solutions/Exercise_10_Concessionary_Travel.py', '12 ч\n', 'так'),
    ('5.10 male at threshold', 'Chapter_05_Conditionals/Solutions/Exercise_10_Concessionary_Travel.py', '65 ч\n', 'так'),
    ('6.1 single digit', 'Chapter_06_Loops/Solutions/Exercise_01_Digit_Sum_and_Product.py', '7\n', 'сума = 7, добуток = 7'),
    ('6.2 zero', 'Chapter_06_Loops/Solutions/Exercise_02_Digit_Counts.py', '0\n', 'цифр = 1, парних = 1'),
    ('6.6 prime', 'Chapter_06_Loops/Solutions/Exercise_06_Prime_Check.py', '29\n', 'просте'),
    ('6.6 composite', 'Chapter_06_Loops/Solutions/Exercise_06_Prime_Check.py', '21\n', 'складене'),
    ('6.6 smallest prime', 'Chapter_06_Loops/Solutions/Exercise_06_Prime_Check.py', '2\n', 'просте'),
    ('6.9 n=1', 'Chapter_06_Loops/Solutions/Exercise_09_Primes_Up_to_N.py', '1\n', '(0 чисел)'),
    ('6.10 perfect 6', 'Chapter_06_Loops/Solutions/Exercise_10_Perfect_Number.py', '6\n', 'досконале'),
    ('6.10 not perfect', 'Chapter_06_Loops/Solutions/Exercise_10_Perfect_Number.py', '12\n', 'не досконале'),
]

# Syntax-check every Python source without generating __pycache__ files.
python_files = sorted(root.rglob("*.py"))
for source in python_files:
    compile(source.read_text(encoding="utf-8"), str(source), "exec")

errors=[]
all_tests = list(paths.items()) + [(name,(rel,stdin,expected)) for name,rel,stdin,expected in extra_tests]
for key,(rel,stdin,expected) in all_tests:
    old_stdin, old_stdout = sys.stdin, sys.stdout
    captured = io.StringIO()
    try:
        sys.stdin = io.StringIO(stdin)
        sys.stdout = captured
        runpy.run_path(str(root / rel), run_name="__main__")
        output = captured.getvalue().strip()
    except BaseException as exc:
        errors.append((key, repr(exc), expected, "", type(exc).__name__))
        continue
    finally:
        sys.stdin, sys.stdout = old_stdin, old_stdout
    if output != expected:
        errors.append((key, output, expected, "", 0))

total_tests = len(all_tests)
print(f"Syntax checks: {len(python_files)} passed. Sample and boundary tests: {total_tests-len(errors)}/{total_tests} passed.")
for err in errors:
    print("FAIL", err)
if errors:
    sys.exit(1)

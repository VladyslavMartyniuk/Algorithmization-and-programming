# Algorithmization and Programming — Solutions

Цей архів містить розв’язання всіх практичних завдань розділів 1–6 включно — до розділу 7 «Рядки» — курсу [«Алгоритмізація та програмування»](https://github.com/DimaGapfild/alhorytmizatsiia-ta-prohramuvannia).

## Contents

- `Chapter_01_Algorithmization/Solutions.md` — постановки задач, формули, словесні алгоритми й тести.
- `Chapter_02_Flowcharts_and_Pseudocode/Solutions.md` — блок-схеми Mermaid, псевдокод і трасування.
- `Chapter_03_Python_Basics/Solutions/` — 10 окремих Python-програм.
- `Chapter_04_Linear_Algorithms/Solutions/` — 10 Python-програм із цілочисловою арифметикою.
- `Chapter_05_Conditionals/Solutions/` — 10 Python-програм із розгалуженнями.
- `Chapter_06_Loops/Solutions/` — 10 Python-програм із циклами й накопичувачами.
- `Review.md` — огляд навчальних матеріалів і зауваження.
- `Test_Results.md` and `tests/test_samples.py` — результати та скрипт перевірки.

## Run a program

Потрібен Python 3. Запускайте кожну вправу окремо, наприклад:

```bash
python Chapter_06_Loops/Solutions/Exercise_07_Fibonacci.py
```

Програми читають вхідні дані через `input()`. Вправи розділів 1–2 подано як навчальні алгоритми, псевдокод, блок-схеми й трасування; розділів 3–6 — як окремі Python-програми.

## Notes

Розв’язання зібрано окремо від оригінального репозиторію. Підключений GitHub мав права читання, але не запису для вихідного репозиторію, тому жодних змін не було committed до нього.
